//
//  LogbookActionView.swift
//  SailTrips
//
//  Created by jeroen kok on 25/11/2025.
//

//
//  LogActionView.swift
//  SailTrips
//
//  Created by ChatGPT on 25/11/2025.
//

import SwiftUI
import SwiftData

struct LogActionsView: View {
    @Environment(\.modelContext) private var modelContext

    let registry: ActionRegistry
    let situation: SituationID
    let instances: Instances
    let boat: Boat?

    var body: some View {
        let runtime = ActionRuntime(
            modelContext: modelContext,
            instances: instances,
            boat: boat
        )
        
        let def = SituationDefinition
        let definition = def.
        let actions = registry.visibleVariants(
            for: definition.actionTags,
            in: runtime
        )

        // Render your grid/rows based on actions
        VStack {
            Text(definition.title).font(.headline)
            ForEach(actions) { variant in
                Button {
                    Task { await variant.handler(runtime) }
                } label: {
                    Label {
                        Text(variant.title)
                    } icon: {
                        if let sf = variant.systemImage {
                            Image(systemName: sf)
                        }
                    }
                }
                .buttonStyle(.borderedProminent)
            }
        }
    }
}

struct LogActionView2: View {
    @Environment(\.modelContext) private var modelContext
    @Bindable var instances: Instances
    var settings: LogbookSettings

    // For v1: choose the situation manually via a Picker
    @State private var currentSituation: situationMap = .s1Preparing

    @State private var bannerText: String?
    @State private var showBanner: Bool = false
    @State private var showDangerSheet: Bool = false
    @State private var pendingDangerVariant: ActionVariant? = nil

    var body: some View {
        VStack(spacing: 0) {

            // Title bar (for now: simple, with a debug situation chooser)
            HStack {
                Text("Action Log")
                    .font(.title2)
                    .fontWeight(.semibold)
                Spacer()

                Menu {
                    Picker("Situation", selection: $currentSituation) {
                        ForEach(LogActionSituation.allCases) { situation in
                            Text(situation.label).tag(situation)
                        }
                    }
                } label: {
                    Label("Situation", systemImage: "slider.horizontal.3")
                        .labelStyle(.iconOnly)
                }
            }
            .padding([.horizontal, .top])

            Divider()

            // Top fixed bar
            topFixedBar

            Divider()

            // Scrollable grid of contextual actions
            ScrollView {
                LazyVGrid(
                    columns: [GridItem(.adaptive(minimum: 70), spacing: 10)],
                    spacing: 10
                ) {
                    ForEach(ActionRegistry.shared.visibleVariants(for: currentSituation,
                                                                  instances: instances)) { variant in
                        Button {
                            runAction(variant)
                        } label: {
                            VStack(spacing: 8) {
                                iconView(for: variant.icon)
                                    .font(.system(size: 24))
                                Text(variant.title)
                                    .font(.footnote)
                                    .multilineTextAlignment(.center)
                            }
                            .padding()
                            .frame(maxWidth: .infinity)
                            .background(.thinMaterial)
                            .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
                        }
                    }

                }
                .padding()
            }
        }
        .sheet(isPresented: $showDangerSheet) {
            DangerReporterView(
                existing: instances.environmentDangers
            ) { newDangers, notes in
                handleDangerReporterResult(newDangers: newDangers, notes: notes)
            }
        }
        .overlay(alignment: .bottom) {
            if showBanner, let text = bannerText {
                Text(text)
                    .padding(.horizontal, 16)
                    .padding(.vertical, 8)
                    .background(.ultraThinMaterial)
                    .clipShape(Capsule())
                    .padding(.bottom, 12)
                    .transition(.move(edge: .bottom).combined(with: .opacity))
            }
        }
        .animation(.easeInOut(duration: 0.25), value: showBanner)
        .navigationBarTitleDisplayMode(.inline)
    }

    // MARK: - Top bar

    private var topFixedBar: some View {
        // permanentTopBarGroups currently returns the groups in this order:
        // 0: emergencies
        // 1: checklists / incidents
        // 2: motor
        // 3: environment
        // 4: other logs
        // 5: navigation
        let groups = ActionRegistry.shared.permanentTopBarGroups(instances: instances)

        let emergencies         = groups.indices.contains(0) ? groups[0] : []
        let checklistsIncidents = groups.indices.contains(1) ? groups[1] : []
        let motor               = groups.indices.contains(2) ? groups[2] : []
        let environment         = groups.indices.contains(3) ? groups[3] : []
        let otherLogs           = groups.indices.contains(4) ? groups[4] : []
        let navigation          = groups.indices.contains(5) ? groups[5] : []

        return VStack(alignment: .leading, spacing: 6) {

            // 1. Emergencies : E1, E2, E3
            if !emergencies.isEmpty {
                topBarRow(
                    title: "Emergencies",
                    variants: emergencies
                )
            }

            // 2. Checklists, incidents : AF8, AF7, AF4
            if !checklistsIncidents.isEmpty {
                topBarRow(
                    title: "Checklists / Incidents",
                    variants: checklistsIncidents
                )
            }

            // 3. Motor : [AF2]/[AF21], Navigation : {AF12}, AF14, AF11, AF16
            if !motor.isEmpty || !navigation.isEmpty {
                topBarRow(
                    title: "Motor / Navigation",
                    variants: motor + navigation
                )
            }

            // 4. Environment : AF3, AF9, AF10, AF1
            if !environment.isEmpty {
                topBarRow(
                    title: "Environment",
                    variants: environment
                )
            }

            // 5. Other logs : AF5, AF6, AF15
            if !otherLogs.isEmpty {
                topBarRow(
                    title: "Other logs",
                    variants: otherLogs
                )
            }
        }
        .padding(.horizontal)
        .padding(.vertical, 8)
    }

    @ViewBuilder
    private func topBarRow(
        title: String,
        variants: [ActionVariant]
    ) -> some View {

        let isEmergencyRow = (title == "Emergencies")

        HStack(spacing: isEmergencyRow ? 14 : 8) {
 
            Text(title + " :")
                .font(isEmergencyRow ? .callout.weight(.semibold) : .caption)
                .foregroundColor(isEmergencyRow ? .red : .primary)

            // Optional icon:
            // if isEmergencyRow {
            //     Image(systemName: "exclamationmark.triangle.fill")
            //         .foregroundColor(.red)
            // }


            ForEach(variants) { variant in
                Button {
                    runAction(variant)
                } label: {
                    HStack(spacing: 4) {
                        iconView(for: variant.icon)
                            .font(.system(size: 14))
                        // If you prefer the AF codes instead of titles, use `variant.baseID`
                       /* Text(variant.baseID)
                            .font(.caption2)*/
                    }
                    .padding(.horizontal, isEmergencyRow ? 10 : 8)
                    .padding(.vertical,   isEmergencyRow ? 7  : 4)
                    .background(backgroundStyle(for: title))
                    .clipShape(Capsule())
                    .overlay(
                        Capsule()
                            .stroke(borderStyle(for: title), lineWidth: isMotorNavigationRow(title) ? 1 : 0)
                    )
                    .shadow(color: isMotorNavigationRow(title) ? .black.opacity(0.1) : .clear,
                            radius: isMotorNavigationRow(title) ? 2 : 0)

                }
                .buttonStyle(.plain)
            }

            Spacer(minLength: 0)
        }
    }
    // helper functions for display
    
    private func isMotorNavigationRow(_ title: String) -> Bool {
        title == "Motor / Navigation"
    }

    private func backgroundStyle(for title: String) -> AnyShapeStyle {
        if isMotorNavigationRow(title) {
            // Stronger, noticeable background for Motor / Navigation
            return AnyShapeStyle(Color.blue.opacity(0.25))
        } else if title == "Emergencies" {
            // Slight red tint for emergencies
            return AnyShapeStyle(Color.red.opacity(0.15))
        } else {
            // Default look for other rows
            return AnyShapeStyle(.thinMaterial)
        }
    }


    private func borderStyle(for title: String) -> Color {
        if isMotorNavigationRow(title) {
            return .blue.opacity(0.5)
        } else {
            return .clear
        }
    }

    private func isEmergencyRow(_ title: String) -> Bool {
        title == "Emergencies"
    }

    // MARK: - Test action runner
    
    private func runAction(_ variant: ActionVariant) {
        let ctx = ActionContext(
            instances: instances,
            modelContext: modelContext,
            showBanner: { text in
                showBanner(text: text)   // your existing banner logic
            },
            openDangerSheet: { dangerVariant in
                pendingDangerVariant = dangerVariant
                showDangerSheet = true
            }
        )

        variant.run(variant, ctx)
    }

    private func showBanner(text: String) {
        bannerText = text
        showBanner = true
        DispatchQueue.main.asyncAfter(deadline: .now() + 2.0) {
            showBanner = false
        }
    }

    /// Keep environmentDangers non-empty: guarantee [.none] minimum.
    private func normalizeEnvironmentDangers() {
        if instances.environmentDangers.isEmpty {
            instances.environmentDangers = [.none]
        }
    }
    
    /// Called when the DangerReporter sheet completes.
    private func handleDangerReporterResult(
        newDangers: [EnvironmentDangers],
        notes: String
    ) {
        // Ensure non-empty: default to [.none]
        let cleaned = newDangers.isEmpty ? [.none] : newDangers
        instances.environmentDangers = cleaned

        // Build a human-readable description for Instances + log
        let description = dangerSummary(from: cleaned, notes: notes)
        instances.trafficDescription = description

        guard let trip = instances.currentTrip else {
            showBanner(text: "Dangers updated (no active Trip to log).")
            return
        }

        let log = Logs(trip: trip)
        log.dateOfLog = Date()
        log.posLat = instances.gpsCoordinatesLat
        log.posLong = instances.gpsCoordinatesLong
        log.logEntry = "Danger(s) reported: \(description)"

        modelContext.insert(log)

        do {
            try modelContext.save()
            showBanner(text: "Logged dangers")
        } catch {
            showBanner(text: "Could not save danger log (\(error.localizedDescription))")
        }
    }
    private func dangerSummary(
        from dangers: [EnvironmentDangers],
        notes: String
    ) -> String {
        let active = dangers.filter { $0 != .none }
        let labels = active.map { $0.displayName }

        let base: String
        if labels.isEmpty {
            base = "No specific dangers reported"
        } else if labels.count == 1 {
            base = labels[0]
        } else {
            let head = labels.dropLast().joined(separator: ", ")
            base = head + " and " + (labels.last ?? "")
        }

        let trimmedNotes = notes.trimmingCharacters(in: .whitespacesAndNewlines)
        if trimmedNotes.isEmpty {
            return base
        } else {
            return base + " (\(trimmedNotes))"
        }
    }

    @ViewBuilder
    func iconView(for icon: ActionIcon) -> some View {
        switch icon {
        case .sfSymbol(let name):
            Image(systemName: name)
        case .emoji(let symbol):
            Text(symbol)
        }
    }
}
